document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('task-input');
    const dateInput = document.getElementById('date-input');
    const addTaskBtn = document.getElementById('add-task-btn');
    const filterInput = document.getElementById('filter-input');
    const deleteAllBtn = document.getElementById('delete-all-btn');
    const todoList = document.getElementById('todo-list');
    const noTaskMessage = document.getElementById('no-task-message');

    let tasks = [];


    const loadTasks = () => {
        const storedTasks = localStorage.getItem('tasks');
        if (storedTasks) {
            tasks = JSON.parse(storedTasks);
        }
        renderTasks();
    };


    const saveTasks = () => {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    };


    const renderTasks = () => {
        todoList.innerHTML = '';

        if (tasks.length === 0) {
            noTaskMessage.style.display = 'block';
            return;
        } else {
            noTaskMessage.style.display = 'none';
        }

        const filterText = filterInput.value.toLowerCase();

        tasks.forEach((task, index) => {
            const row = document.createElement('tr');
            row.setAttribute('data-index', index);

            const taskCell = document.createElement('td');
            taskCell.textContent = task.text;
            if (task.completed) {
                taskCell.classList.add('completed-task');
            }

            const dateCell = document.createElement('td');
            dateCell.textContent = task.dueDate || 'No date';

            const statusCell = document.createElement('td');
            statusCell.textContent = task.completed ? 'Completed' : 'Pending';

            const actionsCell = document.createElement('td');
            actionsCell.classList.add('task-actions');

            const completeBtn = document.createElement('button');
            completeBtn.textContent = task.completed ? 'Undo' : 'Complete';
            completeBtn.classList.add('complete-btn');
            completeBtn.addEventListener('click', () => toggleComplete(index));

            const deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Delete';
            deleteBtn.classList.add('delete-btn');
            deleteBtn.addEventListener('click', () => deleteTask(index));

            actionsCell.appendChild(completeBtn);
            actionsCell.appendChild(deleteBtn);


            if (task.text.toLowerCase().includes(filterText) || (task.dueDate && task.dueDate.includes(filterText))) {
                row.appendChild(taskCell);
                row.appendChild(dateCell);
                row.appendChild(statusCell);
                row.appendChild(actionsCell);
                todoList.appendChild(row);
            }
        });
    };


    const addTask = () => {
        const taskText = taskInput.value.trim();
        const dueDate = dateInput.value;

        if (taskText === '') {
            alert('Task cannot be empty!');
            return;
        }


        if (dueDate && new Date(dueDate) < new Date(new Date().setHours(0,0,0,0))) {
            alert('Due date cannot be in the past!');
            return;
        }

        tasks.push({ text: taskText, dueDate: dueDate, completed: false });
        saveTasks();
        renderTasks();
        taskInput.value = '';
        dateInput.value = '';
    };


    const toggleComplete = (index) => {
        if (index >= 0 && index < tasks.length) {
            tasks[index].completed = !tasks[index].completed;
            saveTasks();
            renderTasks();
        }
    };


    const deleteTask = (index) => {
        if (index >= 0 && index < tasks.length) {
            tasks.splice(index, 1);
            saveTasks();
            renderTasks();
        }
    };


    const deleteAllTasks = () => {
        if (confirm('Are you sure you want to delete all tasks?')) {
            tasks = [];
            saveTasks();
            renderTasks();
        }
    };


    addTaskBtn.addEventListener('click', addTask);
    filterInput.addEventListener('input', renderTasks);
    deleteAllBtn.addEventListener('click', deleteAllTasks);


    taskInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            addTask();
        }
    });


    dateInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            addTask();
        }
    });


    loadTasks();
});
